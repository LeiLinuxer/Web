// CheckStyle: stop header check
// CheckStyle: stop line length check
package com.oracle.svm.core.aarch64;

// GENERATED CONTENT - DO NOT EDIT
// Annotated type: com.oracle.svm.core.aarch64.AArch64FrameAccessFeature
// Annotation: com.oracle.svm.core.feature.AutomaticallyRegisteredFeature
// Annotation processor: com.oracle.svm.processor.AutomaticallyRegisteredFeatureProcessor

import com.oracle.svm.core.feature.AutomaticallyRegisteredFeatureServiceRegistration;
import org.graalvm.nativeimage.Platform;
import org.graalvm.nativeimage.Platforms;

@Platforms(Platform.HOSTED_ONLY.class)
public final class AArch64FrameAccessFeature_ServiceRegistration implements AutomaticallyRegisteredFeatureServiceRegistration {
    @Override
    public String getClassName() {
        return "com.oracle.svm.core.aarch64.AArch64FrameAccessFeature";
    }
}
