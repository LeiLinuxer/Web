// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.genscavenge.graal;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.options.ExcludeFromJacocoGeneratedReport;

//        class: com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier
//       method: force(org.graalvm.compiler.nodes.memory.address.AddressNode.Address,boolean)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_ForcedSerialPostWriteBarrier_force extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        boolean arg1;
        if (args[1].isConstant()) {
            arg1 = args[1].asJavaConstant().asInt() != 0;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_ForcedSerialPostWriteBarrier_force.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[1];
            return false;
        }
        com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier node = new com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier(arg0, arg1);
        b.add(node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_ForcedSerialPostWriteBarrier_force() {
        super("force", org.graalvm.compiler.nodes.memory.address.AddressNode.Address.class, boolean.class);
    }
}
//        class: com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier
//       method: force(org.graalvm.compiler.nodes.memory.address.AddressNode.Address,boolean)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_ForcedSerialPostWriteBarrier_force implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_ForcedSerialPostWriteBarrier_force();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        ValueNode arg0 = args.get(0);
        boolean arg1;
        if (args.get(1).isConstant()) {
            arg1 = args.get(1).asJavaConstant().asInt() != 0;
        } else {
            return false;
        }
        com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier node = new com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier(arg0, arg1);
        b.add(node);
        return true;
    }
}

public class PluginFactory_ForcedSerialPostWriteBarrier implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.genscavenge.graal.ForcedSerialPostWriteBarrier.class, new Plugin_ForcedSerialPostWriteBarrier_force());
    }
}
