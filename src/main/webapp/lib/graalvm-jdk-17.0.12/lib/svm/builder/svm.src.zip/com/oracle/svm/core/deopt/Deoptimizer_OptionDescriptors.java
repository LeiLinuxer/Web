// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: Deoptimizer.java
package com.oracle.svm.core.deopt;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class Deoptimizer_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "TraceDeoptimization": {
            return OptionDescriptor.create(
                /*name*/ "TraceDeoptimization",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Print logging information for every deoptimization",
                /*declaringClass*/ Deoptimizer.Options.class,
                /*fieldName*/ "TraceDeoptimization",
                /*option*/ Deoptimizer.Options.TraceDeoptimization,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "TraceDeoptimizationDetails": {
            return OptionDescriptor.create(
                /*name*/ "TraceDeoptimizationDetails",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Print verbose logging information for every deoptimization",
                /*declaringClass*/ Deoptimizer.Options.class,
                /*fieldName*/ "TraceDeoptimizationDetails",
                /*option*/ Deoptimizer.Options.TraceDeoptimizationDetails,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 2;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("TraceDeoptimization");
                    case 1: return get("TraceDeoptimizationDetails");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
