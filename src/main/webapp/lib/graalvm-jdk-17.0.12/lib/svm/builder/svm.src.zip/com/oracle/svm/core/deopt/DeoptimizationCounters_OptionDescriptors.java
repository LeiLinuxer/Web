// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: DeoptimizationCounters.java
package com.oracle.svm.core.deopt;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class DeoptimizationCounters_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "ProfileDeoptimization": {
            return OptionDescriptor.create(
                /*name*/ "ProfileDeoptimization",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Print logging information during object file writing",
                /*declaringClass*/ DeoptimizationCounters.Options.class,
                /*fieldName*/ "ProfileDeoptimization",
                /*option*/ DeoptimizationCounters.Options.ProfileDeoptimization,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 1;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("ProfileDeoptimization");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
