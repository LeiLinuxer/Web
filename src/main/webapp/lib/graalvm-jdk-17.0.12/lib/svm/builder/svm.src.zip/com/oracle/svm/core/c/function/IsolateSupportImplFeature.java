// CheckStyle: stop header check
// CheckStyle: stop line length check
package com.oracle.svm.core.c.function;

// GENERATED CONTENT - DO NOT EDIT
// Annotated type: com.oracle.svm.core.c.function.IsolateSupportImpl
// Annotation: com.oracle.svm.core.feature.AutomaticallyRegisteredImageSingleton
// Annotation processor: com.oracle.svm.processor.AutomaticallyRegisteredImageSingletonProcessor

import org.graalvm.nativeimage.ImageSingletons;
import com.oracle.svm.core.feature.AutomaticallyRegisteredFeature;
import com.oracle.svm.core.feature.InternalFeature;

@AutomaticallyRegisteredFeature
public final class IsolateSupportImplFeature implements InternalFeature {
    @Override
    public void afterRegistration(AfterRegistrationAccess access) {
        var singleton = new com.oracle.svm.core.c.function.IsolateSupportImpl();
        ImageSingletons.add(org.graalvm.nativeimage.impl.IsolateSupport.class, singleton);
    }
}
