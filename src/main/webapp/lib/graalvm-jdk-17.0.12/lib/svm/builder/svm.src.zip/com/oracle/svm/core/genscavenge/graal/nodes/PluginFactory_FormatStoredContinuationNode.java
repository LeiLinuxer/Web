// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.genscavenge.graal.nodes;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.options.ExcludeFromJacocoGeneratedReport;

//        class: com.oracle.svm.core.genscavenge.graal.nodes.FormatStoredContinuationNode
//       method: formatStoredContinuation(org.graalvm.word.Pointer,java.lang.Class<?>,int,boolean,boolean,boolean)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_FormatStoredContinuationNode_formatStoredContinuation extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        ValueNode arg1 = args[1];
        ValueNode arg2 = args[2];
        ValueNode arg3 = args[3];
        ValueNode arg4 = args[4];
        boolean arg5;
        if (args[5].isConstant()) {
            arg5 = args[5].asJavaConstant().asInt() != 0;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_FormatStoredContinuationNode_formatStoredContinuation.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[5];
            return false;
        }
        com.oracle.svm.core.genscavenge.graal.nodes.FormatStoredContinuationNode node = new com.oracle.svm.core.genscavenge.graal.nodes.FormatStoredContinuationNode(arg0, arg1, arg2, arg3, arg4, arg5);
        b.addPush(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_FormatStoredContinuationNode_formatStoredContinuation() {
        super("formatStoredContinuation", org.graalvm.word.Pointer.class, java.lang.Class.class, int.class, boolean.class, boolean.class, boolean.class);
    }
}
//        class: com.oracle.svm.core.genscavenge.graal.nodes.FormatStoredContinuationNode
//       method: formatStoredContinuation(org.graalvm.word.Pointer,java.lang.Class<?>,int,boolean,boolean,boolean)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_FormatStoredContinuationNode_formatStoredContinuation implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_FormatStoredContinuationNode_formatStoredContinuation();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        ValueNode arg0 = args.get(0);
        ValueNode arg1 = args.get(1);
        ValueNode arg2 = args.get(2);
        ValueNode arg3 = args.get(3);
        ValueNode arg4 = args.get(4);
        boolean arg5;
        if (args.get(5).isConstant()) {
            arg5 = args.get(5).asJavaConstant().asInt() != 0;
        } else {
            return false;
        }
        com.oracle.svm.core.genscavenge.graal.nodes.FormatStoredContinuationNode node = new com.oracle.svm.core.genscavenge.graal.nodes.FormatStoredContinuationNode(arg0, arg1, arg2, arg3, arg4, arg5);
        b.addPush(JavaKind.Object, node);
        return true;
    }
}

public class PluginFactory_FormatStoredContinuationNode implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.genscavenge.graal.nodes.FormatStoredContinuationNode.class, new Plugin_FormatStoredContinuationNode_formatStoredContinuation());
    }
}
