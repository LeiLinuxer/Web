// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: RuntimeCodeCache.java
package com.oracle.svm.core.code;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class RuntimeCodeCache_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "TraceCodeCache": {
            return OptionDescriptor.create(
                /*name*/ "TraceCodeCache",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Print logging information for runtime code cache modifications",
                /*declaringClass*/ RuntimeCodeCache.Options.class,
                /*fieldName*/ "TraceCodeCache",
                /*option*/ RuntimeCodeCache.Options.TraceCodeCache,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "WriteableCodeCache": {
            return OptionDescriptor.create(
                /*name*/ "WriteableCodeCache",
                /*optionType*/ OptionType.Expert,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Allocate code cache with write access, allowing inlining of objects",
                /*declaringClass*/ RuntimeCodeCache.Options.class,
                /*fieldName*/ "WriteableCodeCache",
                /*option*/ RuntimeCodeCache.Options.WriteableCodeCache,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 2;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("TraceCodeCache");
                    case 1: return get("WriteableCodeCache");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
