// CheckStyle: stop header check
// CheckStyle: stop line length check
package com.oracle.svm.core;

// GENERATED CONTENT - DO NOT EDIT
// Annotated type: com.oracle.svm.core.UnsafeMemoryUtil
// Annotation: com.oracle.svm.core.feature.AutomaticallyRegisteredImageSingleton
// Annotation processor: com.oracle.svm.processor.AutomaticallyRegisteredImageSingletonProcessor

import org.graalvm.nativeimage.ImageSingletons;
import com.oracle.svm.core.feature.AutomaticallyRegisteredFeature;
import com.oracle.svm.core.feature.InternalFeature;
import org.graalvm.nativeimage.Platforms;

@Platforms({org.graalvm.nativeimage.impl.InternalPlatform.NATIVE_ONLY.class})
@AutomaticallyRegisteredFeature
public final class UnsafeMemoryUtilFeature implements InternalFeature {
    @Override
    public void afterRegistration(AfterRegistrationAccess access) {
        var singleton = new com.oracle.svm.core.UnsafeMemoryUtil();
        ImageSingletons.add(org.graalvm.nativeimage.impl.UnsafeMemorySupport.class, singleton);
    }
}
