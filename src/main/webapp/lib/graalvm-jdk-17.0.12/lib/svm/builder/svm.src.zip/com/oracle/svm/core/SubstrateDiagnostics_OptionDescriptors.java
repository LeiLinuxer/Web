// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: SubstrateDiagnostics.java
package com.oracle.svm.core;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class SubstrateDiagnostics_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "LoopOnFatalError": {
            return OptionDescriptor.create(
                /*name*/ "LoopOnFatalError",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Execute an endless loop before printing diagnostics for a fatal error.",
                /*declaringClass*/ SubstrateDiagnostics.Options.class,
                /*fieldName*/ "LoopOnFatalError",
                /*option*/ SubstrateDiagnostics.Options.LoopOnFatalError,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 1;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("LoopOnFatalError");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
