// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: FallbackExecutor.java
package com.oracle.svm.core;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class FallbackExecutor_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "FallbackExecutorClasspath": {
            return OptionDescriptor.create(
                /*name*/ "FallbackExecutorClasspath",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ String.class,
                /*help*/ "Internal option used to specify Classpath for FallbackExecutor.",
                /*declaringClass*/ FallbackExecutor.Options.class,
                /*fieldName*/ "FallbackExecutorClasspath",
                /*option*/ FallbackExecutor.Options.FallbackExecutorClasspath,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "FallbackExecutorJavaArg": {
            return OptionDescriptor.create(
                /*name*/ "FallbackExecutorJavaArg",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Strings.class,
                /*help*/ "Internal option used to specify java arguments for FallbackExecutor.",
                /*declaringClass*/ FallbackExecutor.Options.class,
                /*fieldName*/ "FallbackExecutorJavaArg",
                /*option*/ FallbackExecutor.Options.FallbackExecutorJavaArg,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "FallbackExecutorMainClass": {
            return OptionDescriptor.create(
                /*name*/ "FallbackExecutorMainClass",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ String.class,
                /*help*/ "Internal option used to specify MainClass for FallbackExecutor.",
                /*declaringClass*/ FallbackExecutor.Options.class,
                /*fieldName*/ "FallbackExecutorMainClass",
                /*option*/ FallbackExecutor.Options.FallbackExecutorMainClass,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "FallbackExecutorRuntimeJavaArg": {
            return OptionDescriptor.create(
                /*name*/ "FallbackExecutorRuntimeJavaArg",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Strings.class,
                /*help*/ "Internal option used to specify runtime java arguments for FallbackExecutor.",
                /*declaringClass*/ FallbackExecutor.Options.class,
                /*fieldName*/ "FallbackExecutorRuntimeJavaArg",
                /*option*/ FallbackExecutor.Options.FallbackExecutorRuntimeJavaArg,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "FallbackExecutorSystemProperty": {
            return OptionDescriptor.create(
                /*name*/ "FallbackExecutorSystemProperty",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Strings.class,
                /*help*/ "Internal option used to specify system properties for FallbackExecutor.",
                /*declaringClass*/ FallbackExecutor.Options.class,
                /*fieldName*/ "FallbackExecutorSystemProperty",
                /*option*/ FallbackExecutor.Options.FallbackExecutorSystemProperty,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 5;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("FallbackExecutorClasspath");
                    case 1: return get("FallbackExecutorJavaArg");
                    case 2: return get("FallbackExecutorMainClass");
                    case 3: return get("FallbackExecutorRuntimeJavaArg");
                    case 4: return get("FallbackExecutorSystemProperty");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
