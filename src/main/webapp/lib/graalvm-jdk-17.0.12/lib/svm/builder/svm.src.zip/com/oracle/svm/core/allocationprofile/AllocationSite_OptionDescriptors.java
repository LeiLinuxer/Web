// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: AllocationSite.java
package com.oracle.svm.core.allocationprofile;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class AllocationSite_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "AllocationProfiling": {
            return OptionDescriptor.create(
                /*name*/ "AllocationProfiling",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Enable runtime profiling of allocation",
                /*declaringClass*/ AllocationSite.Options.class,
                /*fieldName*/ "AllocationProfiling",
                /*option*/ AllocationSite.Options.AllocationProfiling,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "AllocationProfilingThreshold": {
            return OptionDescriptor.create(
                /*name*/ "AllocationProfilingThreshold",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Integer.class,
                /*help*/ "The minimum size in bytes required for printing an allocation profiling entry",
                /*declaringClass*/ AllocationSite.Options.class,
                /*fieldName*/ "AllocationProfilingThreshold",
                /*option*/ AllocationSite.Options.AllocationProfilingThreshold,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "PrintDetailedAllocationProfiling": {
            return OptionDescriptor.create(
                /*name*/ "PrintDetailedAllocationProfiling",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Print detailed information for each allocation site",
                /*declaringClass*/ AllocationSite.Options.class,
                /*fieldName*/ "PrintDetailedAllocationProfiling",
                /*option*/ AllocationSite.Options.PrintDetailedAllocationProfiling,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 3;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("AllocationProfiling");
                    case 1: return get("AllocationProfilingThreshold");
                    case 2: return get("PrintDetailedAllocationProfiling");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
