// CheckStyle: stop header check
// CheckStyle: stop line length check
package com.oracle.svm.core;

// GENERATED CONTENT - DO NOT EDIT
// Annotated type: com.oracle.svm.core.RuntimeAssertionsSupport
// Annotation: com.oracle.svm.core.feature.AutomaticallyRegisteredImageSingleton
// Annotation processor: com.oracle.svm.processor.AutomaticallyRegisteredImageSingletonProcessor

import org.graalvm.nativeimage.ImageSingletons;
import com.oracle.svm.core.feature.AutomaticallyRegisteredFeature;
import com.oracle.svm.core.feature.InternalFeature;
import org.graalvm.nativeimage.Platforms;

@Platforms({org.graalvm.nativeimage.Platform.HOSTED_ONLY.class})
@AutomaticallyRegisteredFeature
public final class RuntimeAssertionsSupportFeature implements InternalFeature {
    @Override
    public void afterRegistration(AfterRegistrationAccess access) {
        var singleton = new com.oracle.svm.core.RuntimeAssertionsSupport();
        ImageSingletons.add(com.oracle.svm.core.RuntimeAssertionsSupport.class, singleton);
    }
}
