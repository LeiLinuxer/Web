// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.code;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.ConstantNode;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.options.ExcludeFromJacocoGeneratedReport;

//        class: com.oracle.svm.core.code.FrameInfoDecoder
//       method: encodeSourceReferences()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_FrameInfoDecoder_encodeSourceReferences extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_FrameInfoDecoder_encodeSourceReferences.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.code.FrameInfoDecoder.encodeSourceReferences();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_FrameInfoDecoder_encodeSourceReferences() {
        super("encodeSourceReferences");
    }
}
//        class: com.oracle.svm.core.code.FrameInfoDecoder
//       method: encodeSourceReferences()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_FrameInfoDecoder_encodeSourceReferences implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_FrameInfoDecoder_encodeSourceReferences();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.code.FrameInfoDecoder.encodeSourceReferences();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

public class PluginFactory_FrameInfoDecoder implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.code.FrameInfoDecoder.class, new Plugin_FrameInfoDecoder_encodeSourceReferences());
    }
}
