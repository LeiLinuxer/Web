// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: AggressiveShrinkCollectionPolicy.java
package com.oracle.svm.core.genscavenge;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class AggressiveShrinkCollectionPolicy_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "ExpectedEdenSize": {
            return OptionDescriptor.create(
                /*name*/ "ExpectedEdenSize",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Long.class,
                /*help*/ "Soft upper limit for used eden size. The hinted GC will be performed if the used eden size exceeds this value.",
                /*declaringClass*/ AggressiveShrinkCollectionPolicy.Options.class,
                /*fieldName*/ "ExpectedEdenSize",
                /*option*/ AggressiveShrinkCollectionPolicy.Options.ExpectedEdenSize,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "UsedEdenProportionThreshold": {
            return OptionDescriptor.create(
                /*name*/ "UsedEdenProportionThreshold",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Double.class,
                /*help*/ "Ratio of used bytes to total allocated bytes for eden space. Setting it to a smaller value will trade more triggered hinted GCs for less resident set size.",
                /*declaringClass*/ AggressiveShrinkCollectionPolicy.Options.class,
                /*fieldName*/ "UsedEdenProportionThreshold",
                /*option*/ AggressiveShrinkCollectionPolicy.Options.UsedEdenProportionThreshold,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 2;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("ExpectedEdenSize");
                    case 1: return get("UsedEdenProportionThreshold");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
