// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: ConfigurationFiles.java
package com.oracle.svm.core.configure;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class ConfigurationFiles_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "ConfigurationFileDirectories": {
            return OptionDescriptor.create(
                /*name*/ "ConfigurationFileDirectories",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Paths.class,
                /*help*/ "Directories directly containing configuration files for dynamic features at runtime.",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "ConfigurationFileDirectories",
                /*option*/ ConfigurationFiles.Options.ConfigurationFileDirectories,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "ConfigurationResourceRoots": {
            return OptionDescriptor.create(
                /*name*/ "ConfigurationResourceRoots",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Strings.class,
                /*help*/ "Resource path above configuration resources for dynamic features at runtime.",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "ConfigurationResourceRoots",
                /*option*/ ConfigurationFiles.Options.ConfigurationResourceRoots,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "DynamicProxyConfigurationFiles": {
            return OptionDescriptor.create(
                /*name*/ "DynamicProxyConfigurationFiles",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Paths.class,
                /*help*/ "One or several (comma-separated) paths to JSON files that specify lists of interfaces that define Java proxy classes.",
                /*extraHelp*/ new String[] {
                         "The structure is an array of arrays of fully qualified interface names.",
                         "",
                         "Example:",
                         "",
                         "    [",
                         "        [\"java.lang.AutoCloseable\", \"java.util.Comparator\"],",
                         "        [\"java.util.Comparator\"],",
                         "        [\"java.util.List\"]",
                         "    ]",
                              },
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "DynamicProxyConfigurationFiles",
                /*option*/ ConfigurationFiles.Options.DynamicProxyConfigurationFiles,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "DynamicProxyConfigurationResources": {
            return OptionDescriptor.create(
                /*name*/ "DynamicProxyConfigurationResources",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Strings.class,
                /*help*/ "Resources describing program elements to be made available for reflection (see ProxyConfigurationFiles).",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "DynamicProxyConfigurationResources",
                /*option*/ ConfigurationFiles.Options.DynamicProxyConfigurationResources,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "JNIConfigurationFiles": {
            return OptionDescriptor.create(
                /*name*/ "JNIConfigurationFiles",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Paths.class,
                /*help*/ "Files describing program elements to be made accessible via JNI (for syntax, see ReflectionConfigurationFiles)",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "JNIConfigurationFiles",
                /*option*/ ConfigurationFiles.Options.JNIConfigurationFiles,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "JNIConfigurationResources": {
            return OptionDescriptor.create(
                /*name*/ "JNIConfigurationResources",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Strings.class,
                /*help*/ "Resources describing program elements to be made accessible via JNI (see JNIConfigurationFiles).",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "JNIConfigurationResources",
                /*option*/ ConfigurationFiles.Options.JNIConfigurationResources,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "PredefinedClassesConfigurationFiles": {
            return OptionDescriptor.create(
                /*name*/ "PredefinedClassesConfigurationFiles",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Paths.class,
                /*help*/ "Files describing predefined classes that can be loaded at runtime.",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "PredefinedClassesConfigurationFiles",
                /*option*/ ConfigurationFiles.Options.PredefinedClassesConfigurationFiles,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "PredefinedClassesConfigurationResources": {
            return OptionDescriptor.create(
                /*name*/ "PredefinedClassesConfigurationResources",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Strings.class,
                /*help*/ "Resources describing predefined classes that can be loaded at runtime.",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "PredefinedClassesConfigurationResources",
                /*option*/ ConfigurationFiles.Options.PredefinedClassesConfigurationResources,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "ReflectionConfigurationFiles": {
            return OptionDescriptor.create(
                /*name*/ "ReflectionConfigurationFiles",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Paths.class,
                /*help*/ "One or several (comma-separated) paths to JSON files that specify which program elements should be made available via reflection.",
                /*extraHelp*/ new String[] {
                         "The JSON object schema is:",
                         "",
                         "    {",
                         "      String name; // fully qualified class name",
                         "      boolean allDeclaredConstructors; // include all declared constructors, see Class.getDeclaredConstructors()",
                         "      boolean allPublicConstructors;   // include all public constructors, see Class.getConstructors()",
                         "      boolean allDeclaredMethods; // include all declared methods, see Class.getDeclaredMethods()",
                         "      boolean allPublicMethods;   // include all public methods, see Class.getMethods()",
                         "      boolean allDeclaredFields;  // include all declared fields, see Class.getDeclaredFields()",
                         "      boolean allPublicFields;    // include all public fields, see Class.getFields()",
                         "      {",
                         "        String name; // method name",
                         "        String[] parameterTypes; // parameter types (optional, use if ambiguous)",
                         "      }[] methods;",
                         "      {",
                         "        String name; // field name",
                         "      }[] fields;",
                         "    }[];",
                         "",
                         "Example:",
                         "",
                         "	[",
                         "	  {",
                         "	    \"name\" : \"java.lang.Class\",",
                         "	    \"allDeclaredConstructors\" : \"true\",",
                         "	    \"allPublicConstructors\" : \"true\",",
                         "	    \"allDeclaredMethods\" : \"true\",",
                         "	    \"allPublicMethods\" : \"true\"",
                         "	  },",
                         "	  {",
                         "	    \"name\" : \"java.lang.String\",",
                         "	    \"fields\" : [",
                         "	      { \"name\" : \"value\" },",
                         "	      { \"name\" : \"hash\" }",
                         "	    ],",
                         "	    \"methods\" : [",
                         "	      { \"name\" : \"<init>\", \"parameterTypes\" : [] },",
                         "	      { \"name\" : \"<init>\", \"parameterTypes\" : [\"char[]\"] },",
                         "	      { \"name\" : \"charAt\" },",
                         "	      { \"name\" : \"format\", \"parameterTypes\" : [\"java.lang.String\", \"java.lang.Object[]\"] },",
                         "	    ]",
                         "	  },",
                         "      {",
                         "        \"name\" : \"java.lang.String$CaseInsensitiveComparator\",",
                         "        \"methods\" : [",
                         "          { \"name\" : \"compare\" }",
                         "        ]",
                         "      }",
                         "	]",
                              },
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "ReflectionConfigurationFiles",
                /*option*/ ConfigurationFiles.Options.ReflectionConfigurationFiles,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "ReflectionConfigurationResources": {
            return OptionDescriptor.create(
                /*name*/ "ReflectionConfigurationResources",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Strings.class,
                /*help*/ "Resources describing program elements to be made available for reflection (see ReflectionConfigurationFiles).",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "ReflectionConfigurationResources",
                /*option*/ ConfigurationFiles.Options.ReflectionConfigurationResources,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "ResourceConfigurationFiles": {
            return OptionDescriptor.create(
                /*name*/ "ResourceConfigurationFiles",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Paths.class,
                /*help*/ "Files describing Java resources to be included in the image.",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "ResourceConfigurationFiles",
                /*option*/ ConfigurationFiles.Options.ResourceConfigurationFiles,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "ResourceConfigurationResources": {
            return OptionDescriptor.create(
                /*name*/ "ResourceConfigurationResources",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Strings.class,
                /*help*/ "Resources describing Java resources to be included in the image.",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "ResourceConfigurationResources",
                /*option*/ ConfigurationFiles.Options.ResourceConfigurationResources,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "SerializationConfigurationFiles": {
            return OptionDescriptor.create(
                /*name*/ "SerializationConfigurationFiles",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Paths.class,
                /*help*/ "One or several (comma-separated) paths to JSON files that specify lists of serialization configurations.",
                /*extraHelp*/ new String[] {
                         "The structure is an array of elements specifying the target serialization/deserialization class.",
                         "",
                         "Example:",
                         "",
                         "    [",
                         "      {",
                         "        \"condition\":{\"typeReachable\":\"app.DataSerializer\"},",
                         "        \"name\":\"java.util.ArrayList\"",
                         "      }",
                         "    ]",
                         "",
                         "For deserializing lambda classes, the capturing class of the lambda needs to be specified in a separate section of the configuration file, for example:",
                         "",
                         "    [",
                         "      \"types\": [",
                         "        {\"name\":\"java.lang.Object\"}",
                         "      ],",
                         "      \"lambdaCapturingTypes\": [",
                         "        {\"name\":\"java.util.Comparator\"}",
                         "      ]",
                         "    ]",
                         "",
                         "This JSON file format is also used for the serialization deny list.",
                         "",
                         "In rare cases an application might explicitly make calls to",
                         "",
                         "    ReflectionFactory.newConstructorForSerialization(Class<?> cl, Constructor<?> constructorToCall)",
                         "",
                         "where the passed `constructorToCall` differs from what would automatically be used if regular serialization of `cl`",
                         "would happen. To also support such serialization usecases it is possible to register serialization for a class with a",
                         "custom constructorToCall. For example, to allow serialization of `org.apache.spark.SparkContext$$anonfun$hadoopFile$1`",
                         "using the DeclaredConstructor of java.lang.Object as custom targetConstructor the following can be used in",
                         "serialization-config.json:",
                         "",
                         "    [",
                         "      {",
                         "        \"condition\":{\"typeReachable\":\"org.apache.spark.SparkContext\"},",
                         "        \"name\":\"org.apache.spark.SparkContext$$anonfun$hadoopFile$1\",",
                         "        \"customTargetConstructorClass\":\"java.lang.Object\"",
                         "      }",
                         "    ]",
                              },
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "SerializationConfigurationFiles",
                /*option*/ ConfigurationFiles.Options.SerializationConfigurationFiles,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "SerializationConfigurationResources": {
            return OptionDescriptor.create(
                /*name*/ "SerializationConfigurationResources",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Strings.class,
                /*help*/ "Resources describing program elements to be made available for serialization (see SerializationConfigurationFiles).",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "SerializationConfigurationResources",
                /*option*/ ConfigurationFiles.Options.SerializationConfigurationResources,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "SerializationDenyConfigurationFiles": {
            return OptionDescriptor.create(
                /*name*/ "SerializationDenyConfigurationFiles",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Paths.class,
                /*help*/ "One or several (comma-separated) paths to JSON files that specify lists of serialization configurations.",
                /*extraHelp*/ new String[] {
                         "The structure is an array of elements specifying the target serialization/deserialization class.",
                         "",
                         "Example:",
                         "",
                         "    [",
                         "      {",
                         "        \"condition\":{\"typeReachable\":\"app.DataSerializer\"},",
                         "        \"name\":\"java.util.ArrayList\"",
                         "      }",
                         "    ]",
                         "",
                         "For deserializing lambda classes, the capturing class of the lambda needs to be specified in a separate section of the configuration file, for example:",
                         "",
                         "    [",
                         "      \"types\": [",
                         "        {\"name\":\"java.lang.Object\"}",
                         "      ],",
                         "      \"lambdaCapturingTypes\": [",
                         "        {\"name\":\"java.util.Comparator\"}",
                         "      ]",
                         "    ]",
                         "",
                         "This JSON file format is also used for the serialization deny list.",
                         "",
                         "In rare cases an application might explicitly make calls to",
                         "",
                         "    ReflectionFactory.newConstructorForSerialization(Class<?> cl, Constructor<?> constructorToCall)",
                         "",
                         "where the passed `constructorToCall` differs from what would automatically be used if regular serialization of `cl`",
                         "would happen. To also support such serialization usecases it is possible to register serialization for a class with a",
                         "custom constructorToCall. For example, to allow serialization of `org.apache.spark.SparkContext$$anonfun$hadoopFile$1`",
                         "using the DeclaredConstructor of java.lang.Object as custom targetConstructor the following can be used in",
                         "serialization-config.json:",
                         "",
                         "    [",
                         "      {",
                         "        \"condition\":{\"typeReachable\":\"org.apache.spark.SparkContext\"},",
                         "        \"name\":\"org.apache.spark.SparkContext$$anonfun$hadoopFile$1\",",
                         "        \"customTargetConstructorClass\":\"java.lang.Object\"",
                         "      }",
                         "    ]",
                              },
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "SerializationDenyConfigurationFiles",
                /*option*/ ConfigurationFiles.Options.SerializationDenyConfigurationFiles,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "SerializationDenyConfigurationResources": {
            return OptionDescriptor.create(
                /*name*/ "SerializationDenyConfigurationResources",
                /*optionType*/ OptionType.User,
                /*optionValueType*/ com.oracle.svm.core.option.LocatableMultiOptionValue.Strings.class,
                /*help*/ "Resources describing program elements that must not be made available for serialization.",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "SerializationDenyConfigurationResources",
                /*option*/ ConfigurationFiles.Options.SerializationDenyConfigurationResources,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "StrictConfiguration": {
            return OptionDescriptor.create(
                /*name*/ "StrictConfiguration",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Causes unknown attributes in configuration objects to abort the image build instead of emitting a warning.",
                /*declaringClass*/ ConfigurationFiles.Options.class,
                /*fieldName*/ "StrictConfiguration",
                /*option*/ ConfigurationFiles.Options.StrictConfiguration,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 17;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("ConfigurationFileDirectories");
                    case 1: return get("ConfigurationResourceRoots");
                    case 2: return get("DynamicProxyConfigurationFiles");
                    case 3: return get("DynamicProxyConfigurationResources");
                    case 4: return get("JNIConfigurationFiles");
                    case 5: return get("JNIConfigurationResources");
                    case 6: return get("PredefinedClassesConfigurationFiles");
                    case 7: return get("PredefinedClassesConfigurationResources");
                    case 8: return get("ReflectionConfigurationFiles");
                    case 9: return get("ReflectionConfigurationResources");
                    case 10: return get("ResourceConfigurationFiles");
                    case 11: return get("ResourceConfigurationResources");
                    case 12: return get("SerializationConfigurationFiles");
                    case 13: return get("SerializationConfigurationResources");
                    case 14: return get("SerializationDenyConfigurationFiles");
                    case 15: return get("SerializationDenyConfigurationResources");
                    case 16: return get("StrictConfiguration");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
