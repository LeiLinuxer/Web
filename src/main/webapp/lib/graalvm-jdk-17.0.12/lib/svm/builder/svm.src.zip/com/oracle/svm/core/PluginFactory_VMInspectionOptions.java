// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.ConstantNode;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.options.ExcludeFromJacocoGeneratedReport;

//        class: com.oracle.svm.core.VMInspectionOptions
//       method: getHeapdumpsCommandArgument()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_VMInspectionOptions_getHeapdumpsCommandArgument extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_VMInspectionOptions_getHeapdumpsCommandArgument.FUNCTION);
            return true;
        }
        java.lang.String result = com.oracle.svm.core.VMInspectionOptions.getHeapdumpsCommandArgument();
        JavaConstant constant = b.getConstantReflection()/* A CONSTANT_REFLECTION */.forString(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_VMInspectionOptions_getHeapdumpsCommandArgument() {
        super("getHeapdumpsCommandArgument");
    }
}
//        class: com.oracle.svm.core.VMInspectionOptions
//       method: getHeapdumpsCommandArgument()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_VMInspectionOptions_getHeapdumpsCommandArgument implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_VMInspectionOptions_getHeapdumpsCommandArgument();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        java.lang.String result = com.oracle.svm.core.VMInspectionOptions.getHeapdumpsCommandArgument();
        JavaConstant constant = b.getConstantReflection()/* B CONSTANT_REFLECTION */.forString(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.VMInspectionOptions
//       method: hasHeapDumpSupport()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_VMInspectionOptions_hasHeapDumpSupport extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_VMInspectionOptions_hasHeapDumpSupport.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.VMInspectionOptions.hasHeapDumpSupport();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_VMInspectionOptions_hasHeapDumpSupport() {
        super("hasHeapDumpSupport");
    }
}
//        class: com.oracle.svm.core.VMInspectionOptions
//       method: hasHeapDumpSupport()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_VMInspectionOptions_hasHeapDumpSupport implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_VMInspectionOptions_hasHeapDumpSupport();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.VMInspectionOptions.hasHeapDumpSupport();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.VMInspectionOptions
//       method: hasJfrSupport()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_VMInspectionOptions_hasJfrSupport extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_VMInspectionOptions_hasJfrSupport.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.VMInspectionOptions.hasJfrSupport();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_VMInspectionOptions_hasJfrSupport() {
        super("hasJfrSupport");
    }
}
//        class: com.oracle.svm.core.VMInspectionOptions
//       method: hasJfrSupport()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_VMInspectionOptions_hasJfrSupport implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_VMInspectionOptions_hasJfrSupport();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.VMInspectionOptions.hasJfrSupport();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.VMInspectionOptions
//       method: hasJmxClientSupport()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_VMInspectionOptions_hasJmxClientSupport extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_VMInspectionOptions_hasJmxClientSupport.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.VMInspectionOptions.hasJmxClientSupport();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_VMInspectionOptions_hasJmxClientSupport() {
        super("hasJmxClientSupport");
    }
}
//        class: com.oracle.svm.core.VMInspectionOptions
//       method: hasJmxClientSupport()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_VMInspectionOptions_hasJmxClientSupport implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_VMInspectionOptions_hasJmxClientSupport();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.VMInspectionOptions.hasJmxClientSupport();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.VMInspectionOptions
//       method: hasJmxServerSupport()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_VMInspectionOptions_hasJmxServerSupport extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_VMInspectionOptions_hasJmxServerSupport.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.VMInspectionOptions.hasJmxServerSupport();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_VMInspectionOptions_hasJmxServerSupport() {
        super("hasJmxServerSupport");
    }
}
//        class: com.oracle.svm.core.VMInspectionOptions
//       method: hasJmxServerSupport()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_VMInspectionOptions_hasJmxServerSupport implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_VMInspectionOptions_hasJmxServerSupport();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.VMInspectionOptions.hasJmxServerSupport();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.VMInspectionOptions
//       method: hasJvmstatSupport()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_VMInspectionOptions_hasJvmstatSupport extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_VMInspectionOptions_hasJvmstatSupport.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.VMInspectionOptions.hasJvmstatSupport();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_VMInspectionOptions_hasJvmstatSupport() {
        super("hasJvmstatSupport");
    }
}
//        class: com.oracle.svm.core.VMInspectionOptions
//       method: hasJvmstatSupport()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_VMInspectionOptions_hasJvmstatSupport implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_VMInspectionOptions_hasJvmstatSupport();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.VMInspectionOptions.hasJvmstatSupport();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

public class PluginFactory_VMInspectionOptions implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.VMInspectionOptions.class, new Plugin_VMInspectionOptions_getHeapdumpsCommandArgument());
        plugins.register(com.oracle.svm.core.VMInspectionOptions.class, new Plugin_VMInspectionOptions_hasHeapDumpSupport());
        plugins.register(com.oracle.svm.core.VMInspectionOptions.class, new Plugin_VMInspectionOptions_hasJfrSupport());
        plugins.register(com.oracle.svm.core.VMInspectionOptions.class, new Plugin_VMInspectionOptions_hasJmxClientSupport());
        plugins.register(com.oracle.svm.core.VMInspectionOptions.class, new Plugin_VMInspectionOptions_hasJmxServerSupport());
        plugins.register(com.oracle.svm.core.VMInspectionOptions.class, new Plugin_VMInspectionOptions_hasJvmstatSupport());
    }
}
