// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.graal.jdk;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.PluginReplacementWithExceptionNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.options.ExcludeFromJacocoGeneratedReport;

//        class: com.oracle.svm.core.graal.jdk.SubstrateArraycopySnippets.SubstrateGenericArrayCopyCallNode
//       method: genericArraycopy(java.lang.Object,int,java.lang.Object,int,int,jdk.vm.ci.meta.JavaKind)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_SubstrateGenericArrayCopyCallNode_genericArraycopy extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        ValueNode arg1 = args[1];
        ValueNode arg2 = args[2];
        ValueNode arg3 = args[3];
        ValueNode arg4 = args[4];
        jdk.vm.ci.meta.JavaKind arg5;
        if (args[5].isConstant()) {
            arg5 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(jdk.vm.ci.meta.JavaKind.class, args[5].asJavaConstant());
            assert arg5 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePluginWithException(this, targetMethod, args, PluginReplacementNode_SubstrateGenericArrayCopyCallNode_genericArraycopy.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[5];
            return false;
        }
        com.oracle.svm.core.graal.jdk.SubstrateArraycopySnippets.SubstrateGenericArrayCopyCallNode node = new com.oracle.svm.core.graal.jdk.SubstrateArraycopySnippets.SubstrateGenericArrayCopyCallNode(arg0, arg1, arg2, arg3, arg4, arg5);
        b.addPush(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_SubstrateGenericArrayCopyCallNode_genericArraycopy(GeneratedPluginInjectionProvider injection) {
        super("genericArraycopy", java.lang.Object.class, int.class, java.lang.Object.class, int.class, int.class, jdk.vm.ci.meta.JavaKind.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.graal.jdk.SubstrateArraycopySnippets.SubstrateGenericArrayCopyCallNode
//       method: genericArraycopy(java.lang.Object,int,java.lang.Object,int,int,jdk.vm.ci.meta.JavaKind)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateGenericArrayCopyCallNode_genericArraycopy implements PluginReplacementWithExceptionNode.ReplacementWithExceptionFunction {
    static PluginReplacementWithExceptionNode.ReplacementWithExceptionFunction FUNCTION = new PluginReplacementNode_SubstrateGenericArrayCopyCallNode_genericArraycopy();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        ValueNode arg0 = args.get(0);
        ValueNode arg1 = args.get(1);
        ValueNode arg2 = args.get(2);
        ValueNode arg3 = args.get(3);
        ValueNode arg4 = args.get(4);
        jdk.vm.ci.meta.JavaKind arg5;
        if (args.get(5).isConstant()) {
            arg5 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(jdk.vm.ci.meta.JavaKind.class, args.get(5).asJavaConstant());
            assert arg5 != null;
        } else {
            return false;
        }
        com.oracle.svm.core.graal.jdk.SubstrateArraycopySnippets.SubstrateGenericArrayCopyCallNode node = new com.oracle.svm.core.graal.jdk.SubstrateArraycopySnippets.SubstrateGenericArrayCopyCallNode(arg0, arg1, arg2, arg3, arg4, arg5);
        b.addPush(JavaKind.Int, node);
        return true;
    }
}

public class PluginFactory_SubstrateArraycopySnippets implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.graal.jdk.SubstrateArraycopySnippets.SubstrateGenericArrayCopyCallNode.class, new Plugin_SubstrateGenericArrayCopyCallNode_genericArraycopy(injection));
    }
}
