// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.genscavenge.graal.nodes;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;

//        class: com.oracle.svm.core.genscavenge.graal.nodes.FormatObjectNode
//       method: formatObject(org.graalvm.word.Pointer,java.lang.Class<?>,boolean,org.graalvm.compiler.replacements.AllocationSnippets.FillContent,boolean)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_FormatObjectNode_formatObject extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        ValueNode arg1 = args[1];
        ValueNode arg2 = args[2];
        ValueNode arg3 = args[3];
        ValueNode arg4 = args[4];
        com.oracle.svm.core.genscavenge.graal.nodes.FormatObjectNode node = new com.oracle.svm.core.genscavenge.graal.nodes.FormatObjectNode(arg0, arg1, arg2, arg3, arg4);
        b.addPush(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_FormatObjectNode_formatObject() {
        super("formatObject", org.graalvm.word.Pointer.class, java.lang.Class.class, boolean.class, org.graalvm.compiler.replacements.AllocationSnippets.FillContent.class, boolean.class);
    }
}

public class PluginFactory_FormatObjectNode implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.genscavenge.graal.nodes.FormatObjectNode.class, new Plugin_FormatObjectNode_formatObject());
    }
}
