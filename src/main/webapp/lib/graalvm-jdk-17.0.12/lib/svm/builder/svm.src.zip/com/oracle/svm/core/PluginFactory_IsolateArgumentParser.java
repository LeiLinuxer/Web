// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.ConstantNode;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.options.ExcludeFromJacocoGeneratedReport;

//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getOptionIndex(com.oracle.svm.core.option.RuntimeOptionKey<?>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_IsolateArgumentParser_getOptionIndex extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_IsolateArgumentParser_getOptionIndex.FUNCTION);
            return true;
        }
        @SuppressWarnings({"rawtypes"})
        com.oracle.svm.core.option.RuntimeOptionKey arg0;
        if (args[0].isConstant()) {
            arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(com.oracle.svm.core.option.RuntimeOptionKey.class, args[0].asJavaConstant());
            assert arg0 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_IsolateArgumentParser_getOptionIndex.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        int result = com.oracle.svm.core.IsolateArgumentParser.getOptionIndex(arg0);
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_IsolateArgumentParser_getOptionIndex(GeneratedPluginInjectionProvider injection) {
        super("getOptionIndex", com.oracle.svm.core.option.RuntimeOptionKey.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getOptionIndex(com.oracle.svm.core.option.RuntimeOptionKey<?>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_IsolateArgumentParser_getOptionIndex implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_IsolateArgumentParser_getOptionIndex();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        @SuppressWarnings({"rawtypes"})
        com.oracle.svm.core.option.RuntimeOptionKey arg0;
        if (args.get(0).isConstant()) {
            arg0 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(com.oracle.svm.core.option.RuntimeOptionKey.class, args.get(0).asJavaConstant());
            assert arg0 != null;
        } else {
            return false;
        }
        int result = com.oracle.svm.core.IsolateArgumentParser.getOptionIndex(arg0);
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getStructSize()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_IsolateArgumentParser_getStructSize extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_IsolateArgumentParser_getStructSize.FUNCTION);
            return true;
        }
        int result = com.oracle.svm.core.IsolateArgumentParser.getStructSize();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_IsolateArgumentParser_getStructSize() {
        super("getStructSize");
    }
}
//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: getStructSize()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_IsolateArgumentParser_getStructSize implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_IsolateArgumentParser_getStructSize();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        int result = com.oracle.svm.core.IsolateArgumentParser.getStructSize();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: singleton()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_IsolateArgumentParser_singleton extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_IsolateArgumentParser_singleton.FUNCTION);
            return true;
        }
        com.oracle.svm.core.IsolateArgumentParser result = com.oracle.svm.core.IsolateArgumentParser.singleton();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_IsolateArgumentParser_singleton(GeneratedPluginInjectionProvider injection) {
        super("singleton");
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.IsolateArgumentParser
//       method: singleton()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@ExcludeFromJacocoGeneratedReport("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_IsolateArgumentParser_singleton implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_IsolateArgumentParser_singleton();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        com.oracle.svm.core.IsolateArgumentParser result = com.oracle.svm.core.IsolateArgumentParser.singleton();
        JavaConstant constant = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

public class PluginFactory_IsolateArgumentParser implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.IsolateArgumentParser.class, new Plugin_IsolateArgumentParser_getOptionIndex(injection));
        plugins.register(com.oracle.svm.core.IsolateArgumentParser.class, new Plugin_IsolateArgumentParser_getStructSize());
        plugins.register(com.oracle.svm.core.IsolateArgumentParser.class, new Plugin_IsolateArgumentParser_singleton(injection));
    }
}
