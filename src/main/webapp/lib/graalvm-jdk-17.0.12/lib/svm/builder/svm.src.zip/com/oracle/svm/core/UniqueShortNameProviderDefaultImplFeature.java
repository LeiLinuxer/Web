// CheckStyle: stop header check
// CheckStyle: stop line length check
package com.oracle.svm.core;

// GENERATED CONTENT - DO NOT EDIT
// Annotated type: com.oracle.svm.core.UniqueShortNameProviderDefaultImpl
// Annotation: com.oracle.svm.core.feature.AutomaticallyRegisteredImageSingleton
// Annotation processor: com.oracle.svm.processor.AutomaticallyRegisteredImageSingletonProcessor

import org.graalvm.nativeimage.ImageSingletons;
import com.oracle.svm.core.feature.AutomaticallyRegisteredFeature;
import com.oracle.svm.core.feature.InternalFeature;

@AutomaticallyRegisteredFeature
public final class UniqueShortNameProviderDefaultImplFeature implements InternalFeature {
    @Override
    public void afterRegistration(AfterRegistrationAccess access) {
        if (!new com.oracle.svm.core.UniqueShortNameProviderDefaultImpl.UseDefault().getAsBoolean()) {
            return;
        }
        var singleton = new com.oracle.svm.core.UniqueShortNameProviderDefaultImpl();
        ImageSingletons.add(com.oracle.svm.core.UniqueShortNameProvider.class, singleton);
    }
}
